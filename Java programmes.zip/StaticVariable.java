//Static Keyword - variable
import java.io.*;
import java.lang.*;

class StaticVariable
{
	static int x=10;
	static void test()
	{
		x++;
		System.out.println("x ="+x);
	}
	public static void main(String args[])
	{
		System.out.println("Main Block");
		test();
	}
}