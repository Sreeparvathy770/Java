import java.io.*;
import java.lang.*;
class SumClass
{
	int sum(int a,int b)
	{
		return a+b;
	}
	float sum(float	a,float b)
	{
		return a+b;
	}
	double sum(int a,double b)
	{
		return a+b;
	}
	float sum(int a,float b)
	{
		return a+b;
	}
}

class SumMethod
{
	public static void main(String args[])
	{
		SumClass m=new SumClass();
		int n1,n2,n3;
		float f1,f2,f3,f4;
		double d1,d2=0;
		DataInputStream din=new DataInputStream(System.in);
		try
		{
			System.out.println("Enter n1,n2,n3: ");
			n1=Integer.parseInt(din.readLine());
			n2=Integer.parseInt(din.readLine());
			n3=m.sum(n1,n2);
			System.out.println("Sum= "+n3);
			System.out.println("Enter f1,f2,f3: ");
			f1=Float.parseFloat(din.readLine());
			f2=Float.parseFloat(din.readLine());
			f3=m.sum(f1,f2);
			System.out.println("Sum= "+f3);
			System.out.println("Enter d1: ");
			d1=Double.parseDouble(din.readLine());
			d2=m.sum(n1,d2);
			System.out.println("Sum= "+d2);
			f4=m.sum(n2,f1);
			System.out.println("Sum= "+f4);
		}
		catch(Exception e)
		{
			System.out.println("Error" +e);
		}
	}
}
