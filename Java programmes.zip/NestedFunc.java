//Nested Function
import java.io.*;
import java.lang.*;

class Cube
{
	public void cub(int s)
	{
		int c=s*sq(s);
		System.out.println("Cube= "+c);
	}
	public int sq(int a)
	{
		int s=a*a;
		return s;
	}
}

class NestedFunc
{
	public static void main(String args[])
	{
		Cube t=new Cube();
		int a=2;
		t.cub(a);
	}
}