//Narrowing or explicit
import java.io.*;
import java.lang.*;
class AreaCircleEx
{
	public static void main(String args[])
	{
		String str;
		float r;
		DataInputStream din;
		din=new DataInputStream(System.in);
		try
		{
			System.out.println("Enter the radius: ");
			str=din.readLine();
			r=Integer.parseInt(str);
			int area=(int)3.14*(int)r*(int)r;
			System.out.println("Radius= "+r);
			System.out.println("Area= "+area);
		}
		catch(Exception e)
		{	
			System.out.println("Error "+e);			
		}
	}
}