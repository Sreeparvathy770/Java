import java.io.*;
public class Character
{
public static void main(String args[])
{
String str1;
char c;
try
{
	System.out.println("Enter a string ");
	DataInputStream dis=new DataInputStream(System.in);
	str1=dis.readLine();
	System.out.println("Entered string is "+str1);
	System.out.println("Enter a character: ");
	c=(char)dis.read();
	System.out.println("Entered character is "+c);
	
}
catch(IOException e)
{
	System.out.println(e);
}
}
}