//SUPER KEYWORD - Method
import java.io.*;
import java.lang.*;
class Animal
{
	public void eat()//overridden
	{
		System.out.println("Animal Eats");
	}
}
class Cat extends Animal
{
	public void eat()
	{
		super.eat();
		System.out.println("Cat Eats");
		super.eat();
	}
}
class SuperMethod
{
	public static void main(String args[])
	{
		Cat c1=new Cat();
		c1.eat();
	}
}