import java.io.*;
import java.lang.*;
class test
{
	int km,m;
	try
	{
		DataInputStream din=new DataInputStream(System.in);
		void read()
		{
			System.out.println("Enter length in km: ");
			str=din.readLine();
			km=Integer.parseInt(str);
			System.out.println("Enter length in m: ");
			str=din.readLine();
			m=Integer.parseInt(str);
		}
		void add()
		{
			Length l=new Length();
			l.km=this+l.km;
			l.m=this+l.m;
			System.out.println("Sum= "+c.km+" "+"c.m");
		}
	}
}

class Length
{
	public static void main(String args[])
	{
		test t1=new test();
		t1.read();
		t1.add();
		
		test t2=new test();
		t2.read();
		t2.add();
		
		test t3=new test();
		t1.add(t2);
	}
}
