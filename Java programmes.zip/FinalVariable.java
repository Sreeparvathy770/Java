//FINAL KEYWORD - variable
import java.io.*;
import java.lang.*;
class FinalVariable
{
	public static void main(String args[])
	{
		int i=10;
		System.out.println("i is "+i);
		i=i+10;
		System.out.println("i is "+i);
		final int j=20;
		System.out.println("j is "+j);
		j=j+10;
		System.out.println("j is "+j);
	}
}