//widening or implicit
import java.io.*;
import java.lang.*;
class AreaCircle
{
	public static void main(String args[])
	{
		String str;
		int r;
		double area;
		DataInputStream din;
		din=new DataInputStream(System.in);
		try
		{
			System.out.println("Enter the radius: ");
			str=din.readLine();
			r=Integer.parseInt(str);
			area=3.14*r*r;
			System.out.println("Radius= "+r);
			System.out.println("Area= "+area);
		}
		catch(Exception e)
		{	
			System.out.println("Error "+e);			
		}
	}
}