import java.io.*;
import java.lang.*;
class Animal
{
	public Animal()
	{
		System.out.println("Animal constructor");
	}
	public void eat()//overridden
	{
		System.out.println("Animal Eats");
	}
}
class Cat extends Animal
{
	public Cat()
	{
		System.out.println("Cat constructor");
	}
	public void eat()
	{
		System.out.println("Cat Eats");
	}
}
class SingleInh
{
	public static void main(String args[])
	{
		Cat c1=new Cat();
		c1.eat();
	}
}