import java.io.*;
import java.lang.*;
class MatrixSum
{
	public static void main(String args[])
	{
		String str;
		int a[][],b[][],d[][];
		int r,c,i,j,temp=0;
		DataInputStream din;
		din=new DataInputStream(System.in);
		try
		{
			System.out.println("Enter the size: ");
			r=Integer.parseInt(din.readLine());
			c=Integer.parseInt(din.readLine());
			a=new int[r][c];
			b=new int[r][c];
			d=new int[r][c];
			System.out.println("Enter First Array elements: ");
			for(i=0;i<r;i++)
			{
				for(j=0;j<c;j++)
				{
					a[i][j]=Integer.parseInt(din.readLine());
				}
			}
			System.out.println("Array 1: ");
			for(i=0;i<r;i++)
			{
				for(j=0;j<c;j++)
				{
					System.out.print(a[i][j]+" ");
				}
				System.out.println();
			}
			System.out.println("Enter Second Array elements: ");
			for(i=0;i<r;i++)
			{
				for(j=0;j<c;j++)
				{
					b[i][j]=Integer.parseInt(din.readLine());
				}
			}
			System.out.println("Array 2: ");
			for(i=0;i<r;i++)
			{
				for(j=0;j<c;j++)
				{
					System.out.print(b[i][j]);
				}
				System.out.println();
			}
			for(i=0;i<r;i++)
			{
				for(j=0;j<c;j++)
				{
					d[i][j]=a[i][j]+b[i][j];
				}
			}
			for(i=0;i<r;i++)
			{
				for(j=0;j<c;j++)
				{
					System.out.print(d[i][j]);
				}
				System.out.println();
			}
		}
		catch(Exception e)
		{	
			System.out.println("Error "+e);			
		}
	}
}