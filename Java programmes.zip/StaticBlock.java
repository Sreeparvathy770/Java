//Static Keyword - Block
import java.io.*;
import java.lang.*;

class StaticBlock
{
	static
	{
		System.out.println("STATIC Block will execute first before main");
	}
	public static void main(String args[])
	{
		System.out.println("Main Block");
	}
}