import java.io.*;
import java.lang.*;
class length
{
	String str;
	int km;
	int m;
	void read()
	{
		DataInputStream din=new DataInputStream(System.in);
		try
		{
			System.out.println("Enter length in km: ");
			str=din.readLine();
			km=Integer.parseInt(str);
			System.out.println("Enter length in m: ");
			str=din.readLine();
			m=Integer.parseInt(str);
		}
		catch(Exception e)
		{
			System.out.println("Error" +e);
		}
	}
	length add(length len2)
	{
		length l=new length();
		l.km=this.km+len2.km;
		l.m=this.m+len2.m;
		if(l.m>1000)
		{
			l.m=l.m-1000;
			l.km=l.km+1;
		}
		System.out.println("Sum= "+l.km+"km "+l.m+"m");
		return l;
	}
}

class AddLen
{
	public static void main(String args[])
	{
		length len1=new length();
		len1.read();
		
		length len2=new length();
		len2.read();
		
		length len3=new length();
		len3=len1.add(len2);
		//t1.add(t2);
	}
}
