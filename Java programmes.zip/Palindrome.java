import java.io.*;
import java.lang.*;
class test
{
	public int palfunc(int n)
	{
		int rem,rev=0;
		while(n!=0)
		{
			rem=n%10;
			rev=rev*10+rem;
			n=n/10;
		}
		return rev;
	}
}
class Palindrome
{
	public static void main(String args[])
	{
		test t=new test();
		String str;
		int num,rev;
		DataInputStream din;
		din=new DataInputStream(System.in);
		try
		{
			System.out.println("Enter the digit: ");
			num=Integer.parseInt(din.readLine());
			rev=t.palfunc(num);
			if(rev==num)
				System.out.println("PALINDROME");
			else
				System.out.println("NOT PALINDROME");
		}
		catch(Exception e)
		{	
			System.out.println("Error "+e);			
		}
	}
}