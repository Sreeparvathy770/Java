import java.io.*;
public class Numbers
{
public static void main(String args[])
{
int i;
for(i=1;i<=25;i++)
{
	System.out.println(i+" ");
}
}
}