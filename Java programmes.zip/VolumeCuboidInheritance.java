import java.io.*;
import java.lang.*;

class Rectangle
{
	int l,b;
	public Rectangle(int x, int y)
	{
		l=x;
		b=y;
	}
	int vol()
	{
		return(l*b);
	}
}

class Cuboid extends Rectangle
{
	int h;
	public Cuboid(int x,int y, int z)
	{
		super(x,y);
		/*l=x;
		b=y;*/
		h=z;
	}
	int vol()
	{
		return(l*b*h);
	}
}

class VolumeCuboidInheritance
{
	public static void main(String args[])
	{
		Cuboid c=new Cuboid(4,3,5);
		int v=c.vol();
		System.out.println("Volume= "+v);
	}
}