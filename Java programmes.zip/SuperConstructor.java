//SUPER KEYWORD - Constructor
import java.io.*;
import java.lang.*;
class Animal
{
	Animal()
	{
		System.out.println("Animal Constructor");
	}
	public void eat()
	{
		System.out.println("Animal Eats");
	}
}
class Cat extends Animal
{
	Cat()
	{
		super();
		System.out.println("Cat Constructor");
	}
	public void eat()
	{
		
		System.out.println("Cat Eats");
	}
}
class SuperConstructor
{
	public static void main(String args[])
	{
		Cat c1=new Cat(10);
		c1.eat();
	}
}