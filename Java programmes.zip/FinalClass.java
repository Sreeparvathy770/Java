//FINAL KEYWORD - Class
import java.io.*;
import java.lang.*;

final class Animal
{
	public void eat()
	{
		System.out.println("Animal eats");
	}
}

class Cat extends Animal
{
	public void eat()
	{
		System.out.println("Cat eats");
	}
}

class FinalClass
{
	public static void main(String args[])
	{
		Cat c=new Cat();
		c.eat();
	}
}
