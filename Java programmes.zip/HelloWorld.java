public class HelloWorld
{
	public static void main(String args[])
	{
		int count;
		count=args.length;
		System.out.println("No of Args: "+count);
	}
}