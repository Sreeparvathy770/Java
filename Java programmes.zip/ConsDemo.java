import java.io.*;
import java.lang.*;
class demo
{
	demo(int a,int b)
	{
		int s=0;
		s=a+b;
		System.out.println("Sum= "+s);
	}
}

class ConsDemo
{
	public static void main(String args[])
	{
		int n1,n2;
		DataInputStream din=new DataInputStream(System.in);
		try
		{
			System.out.println("Enter n1,n2: ");
			n1=Integer.parseInt(din.readLine());
			n2=Integer.parseInt(din.readLine());
			demo d1=new demo(n1,n2);
		}
		catch(Exception e)
		{
			System.out.println("Error "+e);
		}
	}
}