public class Hello
{
	public static void main(String args[])
	{
		int count,i=0;
		count=args.length;
		System.out.println("No of Args: "+count);
		while(i<count)
		{
			System.out.println("The "+i+"th argument is "+args[i]);
			i++;
		}	
	}
}