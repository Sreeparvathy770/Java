//SUPER KEYWORD - variable
import java.io.*;
import java.lang.*;
class Animal
{
	String col="White";
	public void eat()//overridden
	{
	
		System.out.println("Animal Eats");
		System.out.println("Colour= "+col);
	}
}
class Cat extends Animal
{
	String col="Black";
	public void eat()
	{
		System.out.println("Cat Eats");
		System.out.println("Colour= "+col);
		System.out.println("Colour= "+super.col);
	}
}
class SuperVar
{
	public static void main(String args[])
	{
		Cat c1=new Cat();
		c1.eat();
	}
}