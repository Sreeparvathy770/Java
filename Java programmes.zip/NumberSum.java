import java.io.*;
public class NumberSum
{
public static void main(String args[])
{
String str1;
int x,n,sum=0;
try
{
	System.out.println("Enter x ");
	DataInputStream dis=new DataInputStream(System.in);
	str1=dis.readLine();
	x=Integer.parseInt(str1);
	while(x!=0)
	{
	n=x%10;
	sum=sum+n;
	x=x/10;
	}
	System.out.println("Sum of the number is "+sum);
	
}
catch(IOException e)
{
	System.out.println(e);
}
}
}