//FINAL KEYWORD - Class
import java.io.*;
import java.lang.*;

class First
{
	int a,b;
	public First(int x, int y)
	{
		a=x;
		b=y;
	}
	int sum()
	{
		return(a+b);
	}
}
final class Second extends First
{
	int c;
	public Second(int x,int y, int z)
	{
		super(x,y);
		c=z;
	}
	int sum()
	{
		return(a+b+c);
	}
}

class FinalClassSum
{
	public static void main(String args[])
	{
		Second s=new Second(4,3,5);
		int su=s.sum();
		System.out.println("Sum= "+su);
	}
}
