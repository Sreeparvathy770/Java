import java.io.*;
import java.lang.*;

class test
{
	public void sq(int b)
	{
		int c=b*b;
		System.out.println("Square= "+c);
	}
}

class FuncSquare
{
	public static void main(String args[])
	{
		test t=new test();
		int a=10;
		t.sq(a);
	}
}