import java.io.*;
import java.lang.*;
class digit
{
	public int sum(int x)
	{
		int n,sum=0;
		while(x!=0)
		{
			n=x%10;
			sum=sum+n;
			x=x/10;
		}
		return sum;
	}
}
class FuncSumDigit
{
	public static void main(String args[])
	{
		digit d=new digit();
		String str;
		int num,s;
		DataInputStream din;
		din=new DataInputStream(System.in);
		try
		{
			System.out.println("Enter the digit: ");
			num=Integer.parseInt(din.readLine());
			s=d.sum(num);
			System.out.println("Sum : "+s);
		}
		catch(Exception e)
		{	
			System.out.println("Error "+e);			
		}
	}
}