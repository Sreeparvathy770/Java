import java.io.*;
import java.lang.*;
class ArrayDemo
{
	public static void main(String args[])
	{
		String str;
		int a[];
		int n,i;
		DataInputStream din;
		din=new DataInputStream(System.in);
		try
		{
			System.out.println("Enter the size: ");
			n=Integer.parseInt(din.readLine());
			a=new int[n];
			System.out.println("Enter Array elements: ");
			for(i=0;i<n;i++)
			{
				a[i]=Integer.parseInt(din.readLine());
			}
			System.out.println("Array elements are : ");
			for(i=0;i<n;i++)
			{
				System.out.println(a[i]);
			}
		}
		catch(Exception e)
		{	
			System.out.println("Error "+e);			
		}
	}
}