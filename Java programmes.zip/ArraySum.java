import java.io.*;
import java.lang.*;
class ArraySum
{
	public static void main(String args[])
	{
		String str;
		float a[],sum=0;
		int n,i;
		DataInputStream din;
		din=new DataInputStream(System.in);
		try
		{
			System.out.println("Enter the size: ");
			n=Integer.parseInt(din.readLine());
			a=new float[n];
			System.out.println("Enter Array elements: ");
			for(i=0;i<n;i++)
			{
				a[i]=Float.parseFloat(din.readLine());
				sum=sum+a[i];
			}
			System.out.println("Array elements are : ");
			for(i=0;i<n;i++)
			{
				System.out.println(a[i]);
			}
			System.out.println("Sum= " +sum);
		}
		catch(Exception e)
		{	
			System.out.println("Error "+e);			
		}
	}
}