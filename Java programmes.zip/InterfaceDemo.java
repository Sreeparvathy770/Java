import java.io.*;
import java.lang.*;

interface Shape
{
	final double pi=3.14;
	public double area();
	public void display();
}
 
class Rectangle implements Shape
{
	double l,b;
	Rectangle(double x,double y)
	{
		l=x;
		b=y;
	}
	public double area()
	{
		return(l*b);
	}
	public void display()
	{
		System.out.println("Rectangle Display");
	}
}

class Triangle implements Shape
{
	double l,b;
	Triangle(double x,double y)
	{
		l=x;
		b=y;
	}
	public double area()
	{
		return(0.5*l*b);
	}
	public void display()
	{
		System.out.println("Triangle Display");
	}
}

class Circle implements Shape
{
	double r;
	Circle(double x)
	{
		r=x;
	}
	public double area()
	{
		return(pi*r*r);
	}
	public void display()
	{
		System.out.println("Circle Display");
	}
}

class InterfaceDemo
{
	public static void main(String args[])
	{
		Rectangle r=new Rectangle(4,3);
		r.display();
		Triangle t=new Triangle(4,5);
		t.display();
		Circle c=new Circle(5);
		c.display();
		double ra=r.area();
		double ta=t.area();
		double ca=c.area();
		System.out.println("Area of Rectangle= "+ra);
		System.out.println("Area of Triangle= "+ta);
		System.out.println("Area of Circle= "+ca);
	}
}
