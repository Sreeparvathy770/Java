import java.io.*;
public class ReadNum
{
public static void main(String args[])
{
String str1,str2;
try
{
	System.out.println("Enter x ");
	DataInputStream dis=new DataInputStream(System.in);
	str1=dis.readLine();
	System.out.println("X is "+str1);
	System.out.println("Enter y");
	str2=dis.readLine();
	System.out.println("Y is "+str2);
	
}
catch(IOException e)
{
	System.out.println(e);
}
}
}