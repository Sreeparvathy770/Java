mport java.io.*;
import java.lang.*;
class weight
{
	String str;
	int kg;
	int g;
	void read()
	{
		DataInputStream din=new DataInputStream(System.in);
		try
		{
			System.out.println("Enter Weight in kg: ");
			str=din.readLine();
			kg=Integer.parseInt(str);
			System.out.println("Enter weight in g: ");
			str=din.readLine();
			g=Integer.parseInt(str);
		}
		catch(Exception e)
		{
			System.out.println("Error" +e);
		}
	}
	void add(weight w2)
	{
		weight w=new weight();
		w.kg=this.kg+w2.kg;
		w.g=this.g+w2.g;
		if(w.g>1000)
		{
			w.g=w.g-1000;
			w.kg=l.kg+1;
		}
		System.out.println("Sum= "+w.kg+"kg "+l.g+"g");
	}
}

class Addweight
{
	public static void main(String args[])
	{
		weight w1=new weight();
		w1.read();
		
		weight len2=new weight();
		w2.read();
		
		//length len3=new length();
		//len3=len1.add(len2);
		w1.add(w2);
	}
}
