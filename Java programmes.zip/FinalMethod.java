//FINAL KEYWORD - Method
import java.io.*;
import java.lang.*;

class Animal
{
	public final void eat()
	{
		System.out.println("Animal eats");
	}
}

class Cat extends Animal
{
	public void eat()
	{
		System.out.println("Cat eats");
	}
}

class FinalMethod
{
	public static void main(String args[])
	{
		Cat c=new Cat();
		c.eat();
	}
}
