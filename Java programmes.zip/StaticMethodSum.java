import java.io.*;
import java.lang.*;
class StaticMethodSum
{
	static int sum(int x)
	{
		int i,s=0;
		for(i=0;i<x;i++)
		{
			s=s+i;
		}
		return s;
	}
	public static void main(String args[])
	{
		int n,s=0;
		System.out.println("Enter  limit");
		DataInputStream din=new DataInputStream(System.in);
		try
		{
			n=Integer.parseInt(din.readLine());
			s=sum(n);
			System.out.println("Sum= "+s);
		}
		catch(Exception e)
		{
			System.out.println("Error");
		}
	}
}