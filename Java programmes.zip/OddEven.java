import java.io.*;
public class OddEven
{
public static void main(String args[])
{
try
{
String s1;
int n;
System.out.println("Enter a number: ");
DataInputStream inp=new DataInputStream(System.in);
s1=inp.readLine();
n=Integer.parseInt(s1);
if(n%2==0)
	System.out.println(n+" is even");
else
	System.out.println(n+" is odd");
}
catch(IOException e)
{
System.out.println(e);
}
}
}