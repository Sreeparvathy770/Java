import java.io.*;
public class ReadStr
{
public static void main(String args[])
{
int x=10;
int y=6;
System.out.println("X<Y:"+(x<y));
System.out.println("X>Y:"+(x>y));
}
}